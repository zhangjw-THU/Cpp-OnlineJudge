#include "dog.h"
#include "test.h"
#include <fstream>
#include <iostream>
using namespace std;

int main()
{
	dog dog1( 5, 10 );

	char filename[50],filename_1[50];
	cin >> filename >> filename_1;
	ofstream fout(filename);
	fout << dog1.getWei() << endl;
	fout << dog1.getAge() << endl;
	ofstream fout_1(filename_1, ios_base::out|ios_base::binary);
	fout_1 << dog1.getWei() << endl;
	fout_1 << dog1.getAge() << endl;

	
	ifstream fin(filename);
	int weight, age;
	fin >> weight >> age;
	dog dog2( weight, age );
	/*
	ifstream fin_1(filename);
	int weight, age;
	fin >> weight >> age;
	dog2( weight, age );
	*/
	
	test();
	return 0;
	
}
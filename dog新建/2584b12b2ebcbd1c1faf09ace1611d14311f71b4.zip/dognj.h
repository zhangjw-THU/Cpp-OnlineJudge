class dog
{
public:
	dog( int weight, int age ):weight( weight ),age( age ){}
	int getWei() { return weight; }
	int getAge() { return age; }
	void setWei( int weight ){ this-> weight = weight; }
	void setAge( int age ){ this-> age = age; }
private:
	int weight;
	int age;
};